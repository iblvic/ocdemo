//
//  hookmsg.h
//  MedicalForumDylib
//
//  Created by haosimac on 2023/9/27.
//

extern void documentPath(char *p, char *append);

extern void startHandle(void);
extern void stopHandle(void);
extern void printFileContent(void);
